// Codigo dos Carros

let xCarros = [620, 620, 620, 620, 620, 620];
let yCarros = [40, 93, 143, 205, 258, 315];
let velocidadeCarros = [3, 3.8, 4, 6, 3.5, 2.5];
let alturaCarro = 45;
let comprimentoCarro = 45;

function mostraCarro(){
  for (let i = 0; i < imagemDosCarros.length; i++ ){ 
    image(imagemDosCarros[i], xCarros[i], yCarros[i], comprimentoCarro, alturaCarro);
  }
}
function movimentaCarro(){
  for (let i = 0; i < imagemDosCarros.length; i++){
    xCarros[i] -= velocidadeCarros[i];
  }
}

function voltaPosicaoInicialCarro(){
  for (let i = 0; i < imagemDosCarros.length; i++){
         if (passouCarroTela(xCarros[i])){  
           xCarros[i] = 620;
    }
  }
}

function passouCarroTela(xCarros){
  return xCarros < -60;
}




