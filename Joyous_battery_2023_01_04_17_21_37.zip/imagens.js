// Imagens Do Jogo

let imagemDaEstrada;
let imagemDoAtor;
let imagemDoCarro;
let imagemDoCarro2;
let imagemDoCarro3;

//Sons Do Jogo

let somDaColisao;
let somDosPontos;
let somDaTrilha;

function preload(){
  imagemDaEstrada = loadImage ("imagens/estrada.png");
  imagemDoAtor = loadImage ("imagens/ator-1.png");
  imagemDoCarro = loadImage ("imagens/Audi.png");
  imagemDoCarro2 = loadImage ("imagens/Car.png");
  imagemDoCarro3 = loadImage ("imagens/Mini_truck.png");
  imagemDoCarro4 = loadImage ("imagens/taxi.png");
  imagemDoCarro5 = loadImage ("imagens/Black_viper.png");
  imagemDoCarro6 = loadImage ("imagens/Police.png");
  imagemDosCarros = [imagemDoCarro, imagemDoCarro2, imagemDoCarro3, imagemDoCarro4,                              imagemDoCarro5, imagemDoCarro6];
  
  somDaColisao = loadSound("sons/colidiu.mp3")
  somDaTrilha = loadSound("sons/trilha.mp3")
  somDosPontos = loadSound("sons/pontos.wav")
 }
