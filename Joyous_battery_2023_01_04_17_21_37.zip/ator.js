// Codigos do Ator

let xAtor = 108;
let yAtor = 370;
let alturaAtor = 20;
let comprimentoAtor = 25;
let colisao = false;
let meusPontos = 0;

function mostraAtor(){
  image(imagemDoAtor, xAtor, yAtor, comprimentoAtor, alturaAtor);
  
}

function movimentaAtor(){
  if (keyIsDown(UP_ARROW)){
    yAtor -= 2;
  }
if (keyIsDown(DOWN_ARROW)){
   if(podeSeMover()){
      yAtor += 2;
    }
  }
}

function verificaColisao(){
  //collideRectCircle(x1, y1, width1, height1, cx, cy, diameter)
  for (let i = 0; i < imagemDosCarros.length; i++) {
    colisao = collideRectCircle(xCarros[i], yCarros[i], comprimentoCarro, alturaCarro,                                      xAtor, yAtor, 0 );
    if (colisao){
      voltaAtorPosicaoInicial();
      somDaColisao.play();
      if (pontosMaiorQueZero()){
        meusPontos -= 1;
        
      }
    }
  }
}

function voltaAtorPosicaoInicial(){
  yAtor = 370
}

function incluiPontos(){
  fill(color(75,0,130));
  textAlign(CENTER);
  textSize(20);
  text(meusPontos, width / 5, 26);
}

function marcaPontos(){
  if (yAtor < 18){
    meusPontos += 1;
    somDosPontos.play();
    voltaAtorPosicaoInicial();
  }
}

function pontosMaiorQueZero(){
  return (meusPontos > 0);
}

function podeSeMover(){
  return yAtor < 370;
}
